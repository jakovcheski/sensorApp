package com.example.stevo.sensorapp22;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.Viewport;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {
    TextView accTV;
    EditText ipAddress;
    EditText port;
    Boolean isSocketClosed = false;
    GraphView graph,graph2,graph3;
    Socket s;

    LineGraphSeries<DataPoint> series,series2,series3;
    LineGraphSeries<DataPoint> series4,series5,series6;
    LineGraphSeries<DataPoint> series7,series8,series9;
    int lastX = 0;

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        accTV = findViewById(R.id.textView);
        ipAddress = findViewById(R.id.editText);
        port = findViewById(R.id.editText2);
        graph = findViewById(R.id.graph);
        graph2 = findViewById(R.id.graph2);
        graph3 = findViewById(R.id.graph3);
        series = new LineGraphSeries<>();
        series2 = new LineGraphSeries<>();
        series3 = new LineGraphSeries<>();
        series4 = new LineGraphSeries<>();
        series5 = new LineGraphSeries<>();
        series6 = new LineGraphSeries<>();
        series7 = new LineGraphSeries<>();
        series8 = new LineGraphSeries<>();
        series9 = new LineGraphSeries<>();
        graph.addSeries(series);
        graph.addSeries(series2);
        graph.addSeries(series3);
        graph2.addSeries(series4);
        graph2.addSeries(series5);
        graph2.addSeries(series6);
        graph3.addSeries(series7);
        graph3.addSeries(series8);
        graph3.addSeries(series9);
        series.setColor(Color.GREEN);
        series2.setColor(Color.RED);
        series3.setColor(Color.BLUE);
        series4.setColor(Color.GREEN);
        series5.setColor(Color.RED);
        series6.setColor(Color.BLUE);
        series7.setColor(Color.GREEN);
        series8.setColor(Color.RED);
        series9.setColor(Color.BLUE);
        graph.setTitle("Accelerometer");
        graph2.setTitle("Gyroscope");
        graph3.setTitle("Magnetometer");
        Viewport viewport = graph.getViewport();
        viewport.setYAxisBoundsManual(true);
        viewport.setMinY(-1);
        viewport.setMaxY(1);
        viewport.setScrollable(true);
        Viewport viewport2 = graph2.getViewport();
        viewport2.setYAxisBoundsManual(true);
        viewport2.setMinY(-20);
        viewport2.setMaxY(20);
        viewport2.setScrollable(true);
        Viewport viewport3 = graph3.getViewport();
        viewport3.setYAxisBoundsManual(true);
        viewport3.setMinY(-100);
        viewport3.setMaxY(100);
        viewport3.setScrollable(true);
    }

    public void startConnection(View v) {
        isSocketClosed = false;

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // Get the specified IP and port number
                    String ip = ipAddress.getText().toString();
                    int portNum = Integer.valueOf(port.getText().toString());
                    // Create the socket
                    s = new Socket(ip, portNum);
                    InputStreamReader isr = new InputStreamReader(s.getInputStream());
                    BufferedReader br = new BufferedReader(isr);
                    // Wait for the server to send a message to the client
                    while(!isSocketClosed) {
                        final String message = br.readLine().replaceAll("--n--","\n");
                        final String[] vals=message.split("\n");
                        final float valf[]=new float[9];
                        for(int i=0;i<9;i++)
                           valf[i]=Float.parseFloat(vals[i]);
                        final String fmessage="Accelerometer:\nAX = "+vals[0]+"\nAY = "+vals[1]+"\nAZ = "+vals[2]+
                                "\nGyroscope:\nGX = " + vals[3] + "\nGY = " + vals[4] + "\nGZ =" + vals[5]+
                                "\nMagnetometer:\nMX = " + vals[6] + "\nMY = " + vals[7] + "\nMZ = " + vals[8];
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                accTV.setText(fmessage);
                                series.appendData(new DataPoint(lastX,valf[0]),true,5);
                                series2.appendData(new DataPoint(lastX,valf[1]),true,5);
                                series3.appendData(new DataPoint(lastX,valf[2]),true,5);
                                series4.appendData(new DataPoint(lastX,valf[3]),true,5);
                                series5.appendData(new DataPoint(lastX,valf[4]),true,5);
                                series6.appendData(new DataPoint(lastX,valf[5]),true,5);
                                series7.appendData(new DataPoint(lastX,valf[6]),true,5);
                                series8.appendData(new DataPoint(lastX,valf[7]),true,5);
                                series9.appendData(new DataPoint(lastX,valf[8]),true,5);
                                lastX++;
                            }
                        });
                    }
                }
                catch(Exception e) {
                    Log.e("Socket exception", e.toString());
                }
            }
        });
        thread.start();
    }



    public void stopConnection(View v) {
        if(s != null && s.isConnected() && !s.isClosed()) {
            try {
                isSocketClosed = true;
                s.close();
                String s1="Connection is stopped!";
                accTV.setText(s1);
            }
            catch(Exception e) {
                Log.e("Socket exception 2", e.toString());
            }
        }
    }
}